package com.wallet.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UserChoice1")
public class UserChoice1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String choice = request.getParameter("choice");
		if(choice.equalsIgnoreCase("CreateAccount")) {
			response.sendRedirect("CreateAccountJSP.jsp");
		}
		else if(choice.equalsIgnoreCase("Login")){
			response.sendRedirect("Login.jsp");
		}
	}

}
