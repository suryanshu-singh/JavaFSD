package com.wallet.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wallet.bean.Customer;
import com.wallet.dao.DaoClass;


@WebServlet("/CreateAccountServlet")
public class CreateAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String address = request.getParameter("address");
		String contactno = request.getParameter("contactno");
		String email = request.getParameter("email");
		String pin = request.getParameter("pin");
		Integer x=new Integer(pin);
//		request.getSession().setAttribute("name", name);
//		request.getSession().setAttribute("gender", gender);
//		request.getSession().setAttribute("address", address);
//		request.getSession().setAttribute("contactno", contactno);
//		request.getSession().setAttribute("email", email);
//		request.getSession().setAttribute("pin", pin);
		Customer c = new Customer(name,gender,address,contactno,email,x);
		
		DaoClass dao = new DaoClass();
		dao.createAccount(c);
		request.getSession().setAttribute("ACS", "AccountCreated");
		request.setAttribute("message", "Sucessfully account created!!  Please Login using your credentials");
		RequestDispatcher dispatcher = request.getRequestDispatcher("Login.jsp");
		dispatcher.forward(request, response);
		//response.sendRedirect("Login.jsp");
		
		
	}

}
