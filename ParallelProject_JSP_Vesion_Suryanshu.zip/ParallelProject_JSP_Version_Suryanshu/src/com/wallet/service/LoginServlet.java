package com.wallet.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		try {
			doPost(request,response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		String name = request.getParameter("accountnumber");
		String pass = request.getParameter("pin");
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection dbCon = null;
		try {
			dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3310/parallelproject1?serverTimezone=IST", "root", "");
			System.out.println("Connected for login");
		} catch (SQLException e) {
			System.out.println("Failed to connect");
			e.printStackTrace();
		}

		String fetchQry = "select * from customerdetails";
		Statement stmt1;
		try {
			boolean flag = true;
			stmt1 = dbCon.createStatement();
			ResultSet rs = stmt1.executeQuery(fetchQry);
			while (rs.next()) {
				if (rs.getString("AccountNumber").equalsIgnoreCase(name)
						&& rs.getString("PIN").equalsIgnoreCase(pass)) {
					PrintWriter out = response.getWriter();
					out.println("Into the condition");
					session.setAttribute("userName", rs.getString("Name"));
					request.getSession().setAttribute("Accountnumber",name);
					request.getSession().setAttribute("PIN",pass);
					flag = false;
					break;
				}
			}
			if (flag) {
				response.getWriter().print("Invalid username...");
				response.sendRedirect("index.jsp");
			} else {
				request.setAttribute("message", "Sucessfully Logged in!!!!");
				RequestDispatcher dispatcher = request.getRequestDispatcher("Dashboard.jsp");
				dispatcher.forward(request, response);
				//response.sendRedirect("Dashboard.jsp");
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

}
