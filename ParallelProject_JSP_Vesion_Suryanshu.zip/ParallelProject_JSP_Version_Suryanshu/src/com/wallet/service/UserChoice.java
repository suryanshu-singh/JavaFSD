package com.wallet.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class UserChoice
 */
@WebServlet("/UserChoice")
public class UserChoice extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String choice = request.getParameter("choice");
		if(choice.equalsIgnoreCase("Deposit")) {
			response.sendRedirect("DepositJSP.jsp");
		}
		else if(choice.equalsIgnoreCase("Withdraw")) {
			response.sendRedirect("WithdrawJSP.jsp");
		}
		else if(choice.equalsIgnoreCase("Transfer")) {
			response.sendRedirect("TransferJSP.jsp");
		}
		else if(choice.equalsIgnoreCase("Print")) {
			response.sendRedirect("PrintServlet");
		}
		else if(choice.equalsIgnoreCase("Exit")){
			response.sendRedirect("Logout.jsp");
		}
		response.getWriter().println("User has selected:"+choice);
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
