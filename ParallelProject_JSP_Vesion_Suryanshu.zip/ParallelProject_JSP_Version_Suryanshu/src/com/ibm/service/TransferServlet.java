package com.ibm.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wallet.bean.Customer;
import com.wallet.dao.DaoClass;

@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String accountnumber = request.getParameter("senderaccountnumber");
		Integer acc= new Integer(accountnumber);
		String amount = request.getParameter("amount");
		Integer a = new Integer(amount);
		String amount2 = request.getParameter("recieveraccountnumber");
		Integer a2 = new Integer(amount2);
		Customer c = new Customer(acc,a);
		Customer c1 = new Customer(a2,a);
		DaoClass dao = new DaoClass();
		dao.fundTransfer(a,c,c1);
		request.setAttribute("message", "Sucessfully transferred!!");
		RequestDispatcher dispatcher = request.getRequestDispatcher("Dashboard.jsp");
		dispatcher.forward(request, response);
		//response.getWriter().println("Sucessfully transferred!!");
	}

}
