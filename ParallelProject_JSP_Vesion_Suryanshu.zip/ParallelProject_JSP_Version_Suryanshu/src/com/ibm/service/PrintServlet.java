package com.ibm.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wallet.bean.Customer;
import com.wallet.dao.DaoClass;

@WebServlet("/PrintServlet")
public class PrintServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String accountnumber = request.getParameter("accountnumber");
		//Integer acc= new Integer(accountnumber);
		String s = (String)request.getSession().getAttribute("Accountnumber");
		Integer b = Integer.parseInt(s);
		Customer c = new Customer(b);
		DaoClass dao = new DaoClass();
			try {
				dao.printTransaction(c,request,response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		response.getWriter().println("Sucessfully printed!!");
	}

}
